
 ; Note: This file is recreated by the project wizard whenever the MCU is
 ;       changed and should not be edited by hand
 ;

			; include derivative specific macros
            INCLUDE 'mc9s12c32.inc'

		

