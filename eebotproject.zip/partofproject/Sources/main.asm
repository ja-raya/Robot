;*****************************************************************
;* This stationery serves as the framework for a                 *
;* user application (single file, absolute assembly application) *
;* For a more comprehensive program that                         *
;* demonstrates the more advanced functionality of this          *
;* processor, please see the demonstration applications          *
;* located in the examples subdirectory of the                   *
;* Freescale CodeWarrior for the HC12 Program directory          *
;*****************************************************************

; export symbols
            XDEF Entry, _Startup            ; export 'Entry' symbol
            ABSENTRY Entry        ; for absolute assembly: mark this as application entry point


;NOTE: WHEN READING "REV" actually is the command to turn the eebot 180 degrees
;ALSO NOTE: We may need to change the REV_INT time as we don't know how long it takes to turn 180 degrees yet
;

; Include derivative-specific definitions 
		INCLUDE 'derivative.inc' 
LCD_DAT       EQU       PORTB       ;LCD data port, bits - PB7,...,PB0
LCD_CNTR      EQU       PTJ       ;LCD control port, bits - PE7(RS),PE4(E)
LCD_E         EQU       $80       ;LCD E-signal pin
LCD_RS        EQU       $40       ;LCD RS-signal pin

CLEAR_HOME    EQU       $01
LCD_SEC_LINE  EQU      $C0
LED_PORT      EQU       PTT     ;
LED_DDR       EQU   DDRT
LED_PINMASK   EQU  $40 ;01000000
NULL          EQU   $00



ROMStart          EQU  $4000  ; absolute address to place my code/constant data

FWD_INT           EQU   69       ; 3 second delay (at 23Hz)
REV_INT           EQU   69       ; 3 second delay (at 23Hz)
FWD_TRN_INT       EQU   46       ; 2 second delay (at 23Hz)
REV_TRN_INT       EQU   46       ; 2 second delay (at 23Hz)
START             EQU   0
FWD               EQU   1
REV               EQU   2
ALL_STP           EQU   3
FWD_TRN           EQU   4
REV_TRN           EQU   5

; variable/data section

            ORG RAMStart
 ; Insert here your data definition.
SENSOR_LINE FCB $01
SENSOR_BOW  FCB $23
SENSOR_PORT FCB $45
SENSOR_MID  FCB $67
SENSOR_STBD FCB $89
  
SENSOR_NUM RMB 1
  
TOP_LINE    RMB 20
              FCB NULL
BOT_LINE    RMB 20
              FCB NULL  
DP_FRONT_SENSOR EQU TOP_LINE+3
DP_PORT_SENSOR  EQU BOT_LINE+0
DP_MID_SENSOR   EQU BOT_LINE+3
DP_STBD_SENSOR  EQU BOT_LINE+6
DP_LINE_SENSOR  EQU BOT_LINE+9   
CLEAR_LINE  FCC '                '
              FCB NULL
              
TEMP        RMB 1    
TOF_COUNTER     RMB     1           ; Timer incremented at 23Hz by TOF_ISR
CRNT_STATE      RMB     1           ; Current state register
T_FWD           RMB     1           ; FWD time target
T_REV           RMB     1           ; REV time target
T_FWD_TRN       RMB     1           ; FWD TURN time target
T_REV_TRN       RMB     1           ; REV TURN time target

; code section
            ORG   ROMStart
HEX_TABLE   FCC '0123456789ABCDEF'

Entry:
_Startup:
                
                CLI            ; Enable interrupts
                LDS #$4000
                JSR initLCD
                JSR initAD
                BSET    LED_DDR,LED_PINMASK
                BSET    DDRT, %00110000
                BCLR    PTT,%00110000
                JSR     ENABLE_TOF          ; Start 23Hz timer overflow counter
                MOVB    #ALL_STP, CRNT_STATE  ; Start in idle state

                BSET DDRA, %00011111
                BCLR    PORTA,%00000011

               ; Fill TOP_LINE and BOT_LINE with spaces ($20) so putsLCD doesn't stop early
                LDX     #TOP_LINE
                LDAB    #20
                LDAA    #$20
InitTop:        STAA    1,X+
                DBNE    B,InitTop

                LDX     #BOT_LINE
                LDAB    #20
InitBot:        STAA    1,X+
                DBNE    B,InitBot 
MainLoop:       JSR READ_SENSORS
                JSR DISPLAY_SENSORS
                LDAA #$8A  ;sets cursor to start of line1
                JSR cmd2LCD 
                BRCLR PORTAD0,$04,bowON
                LDAA #$31         ;output �1� if bow sw OFF
                BRA bowOFF
bowON           LDAA #$30           ;output �0� if bow sw ON
bowOFF          JSR       putcLCD
                LDAA #$20;output a space character in ASCII
                JSR       putcLCD
                BRCLR PORTAD0,$08,sternON
                LDAA #$31          ;output �1� if stern sw OFF
                BRA sternOFF

sternON   LDAA #$30       ;output �0� if stern sw ON
sternOFF  JSR putcLCD

                LDAA    LED_PORT
                EORA    #LED_PINMASK
                STAA    LED_PORT
                LDY     #20               ; ~150ms delay (+100ms sensor read = ~250ms)
                JSR     del_50us
                
                LDAA    CRNT_STATE
                JSR     DISPATCHER
                BRA     MainLoop
              
              
              
              
              
READ_SENSORS  CLR     SENSOR_NUM
              LDX     #SENSOR_LINE
              
RS_MAIN_LOOP  LDAA    SENSOR_NUM
              JSR     SELECT_SENSOR
              LDY     #40
              JSR     del_50us
              
              LDAA   #%10000001
              STAA   ATDCTL5
              BRCLR  ATDSTAT0,$80,*;
              
              LDAA ATDDR0L
              STAA 0,X
              CPX #SENSOR_STBD
              BEQ RS_EXIT
              
              INC SENSOR_NUM
              INX
              BRA RS_MAIN_LOOP
              
RS_EXIT              RTS

SELECT_SENSOR PSHA
              LDAA PORTA
              ANDA #%11100011
              STAA TEMP
              
              PULA
              ASLA
              ASLA
              ANDA #%00011100
              
              ORAA TEMP
              STAA PORTA
              RTS  
DISPLAY_SENSORS LDAA SENSOR_BOW
              JSR BIN2ASC
              LDX #DP_FRONT_SENSOR
              STD 0,X
              
              LDAA SENSOR_PORT
              JSR BIN2ASC
              LDX #DP_PORT_SENSOR
              STD 0,X
              
              LDAA SENSOR_MID
              JSR BIN2ASC
              LDX #DP_MID_SENSOR
              STD 0,X
                           
              LDAA SENSOR_STBD
              JSR BIN2ASC
              LDX #DP_STBD_SENSOR
              STD 0,X
                            
              LDAA SENSOR_LINE
              JSR BIN2ASC
              LDX #DP_LINE_SENSOR
              STD 0,X     
              
              LDAA #CLEAR_HOME
              JSR cmd2LCD
               
              LDY #40
              JSR del_50us
              
              LDX #TOP_LINE
              JSR putsLCD
              
              LDAA #LCD_SEC_LINE
              JSR cmd2LCD
              
              LDX #BOT_LINE
              JSR putsLCD
              RTS

DISPATCHER  CMPA  #START   ; If it's the START state
            BNE   NOT_START
            JSR   START_ST ; then call START_ST routine
            BRA   DISP_EXIT ; and exit

NOT_START   CMPA #FWD
            BNE NOT_FWD
            JSR FWD_ST
            BRA DISP_EXIT
NOT_FWD     CMPA #REV
            BNE NOT_REV
            JSR REV_ST
            BRA DISP_EXIT
NOT_REV     CMPA #ALL_STP
            BNE NOT_ALL_STP
            JSR ALL_STP_ST
            BRA DISP_EXIT
            
NOT_ALL_STP CMPA #FWD_TRN
            BNE NOT_FWD_TRN
            JSR FWD_TRN_ST    
            BRA DISP_EXIT
NOT_FWD_TRN CMPA  #REV_TRN ; Else if it's the REV_TRN state
            BNE   NOT_REV_TRN
            JSR   REV_TRN_ST ; then call REV_TRN_ST routine
            BRA   DISP_EXIT ; and exit

NOT_REV_TRN SWI            ; Else the CRNT_ST is not defined, so stop
DISP_EXIT   RTS            ; Exit from the state dispatcher
START_ST    BRCLR PORTAD0, $04, NO_FWD
            JSR INIT_FWD
            MOVB #FWD,CRNT_STATE
            BRA START_EXIT
NO_FWD      NOP            ; Else
START_EXIT  RTS            ; return to the MAIN routine

FWD_ST      BRSET PORTAD0,$04,NO_FWD_BUMP
            JSR INIT_REV
            MOVB #REV,CRNT_STATE
            BRA FWD_EXIT
NO_FWD_BUMP BRSET PORTAD0,$08,FWD_EXIT
            JSR INIT_ALL_STP
            MOVB #ALL_STP,CRNT_STATE
            BRA FWD_EXIT


NO_FWD_TRN  NOP            ; Else
FWD_EXIT    RTS            ; return to the MAIN routine

REV_ST      LDAA  TOF_COUNTER
            CMPA  T_REV
            BNE   NO_REV_TRN
            JSR   INIT_FWD
            MOVB  #FWD, CRNT_STATE
            BRA   REV_EXIT
NO_REV_TRN  NOP            ; Else
REV_EXIT    RTS            ; return to the MAIN routine

ALL_STP_ST  BRSET PORTAD0,$04,NO_START
            BCLR  PTT, %00110000
            MOVB  #START, CRNT_STATE
            BRA   ALL_STP_EXIT
NO_START    NOP            ; Else
ALL_STP_EXIT RTS           ; return to the MAIN routine

FWD_TRN_ST  LDAA  TOF_COUNTER
            CMPA  T_FWD_TRN
            BNE   NO_FWD_FT
            JSR   INIT_FWD
            MOVB  #FWD, CRNT_STATE
            BRA   FWD_TRN_EXIT
NO_FWD_FT   NOP            ; Else
FWD_TRN_EXIT RTS           ; return to the MAIN routine

REV_TRN_ST  LDAA  TOF_COUNTER
            CMPA  T_REV_TRN ; If Tc>Trevturn then
            BNE   NO_FWD_RT ; the robot should go FWD
            JSR   INIT_FWD  ; so initialize the FWD state
            MOVB  #FWD, CRNT_STATE ; set state to FWD
            BRA   REV_TRN_EXIT ; and return
NO_FWD_RT   NOP            ; Else
REV_TRN_EXIT RTS           ; return to the MAIN routine               
INIT_FWD    BCLR  PORTA, %00000011 ; Set FWD direction for both motors
            BSET  PTT, %00110000   ; Turn on the drive motors.
            LDAA  TOF_COUNTER
            ADDA  #FWD_INT
            STAA  T_FWD
            RTS


INIT_REV    BSET  PORTA, %00000001 ; Set REV direction for left motor
            BCLR  PORTA,  %00000010
            
            BSET  PTT, %00110000   ; Turn on the drive motors
            LDAA  TOF_COUNTER
            ADDA  #REV_INT
            STAA  T_REV
            RTS

INIT_ALL_STP BCLR PTT, %00110000   ; Turn off the drive motors
            RTS

INIT_FWD_TRN BSET PORTA, %00000010 ; Set REV dir. for STARBOARD (right) motor
            LDAA  TOF_COUNTER
            ADDA  #FWD_TRN_INT
            STAA  T_FWD_TRN
            RTS

INIT_REV_TRN BCLR PORTA, %00000010 ; Set FWD dir. for STARBOARD (right) motor
            LDAA  TOF_COUNTER
            ADDA  #REV_TRN_INT
            STAA  T_REV_TRN
            RTS
            
            
initLCD       BSET    DDRB,$FF      ; Configure PORTB pins as outputs for LCD Data
              BSET    DDRJ,$C0      ; Configure PTJ pins PJ7(E) and PJ6(RS) as outputs
              LDY     #2000 ; wait for LCD to be ready
              JSR     del_50us ; -"-
              LDAA    #$28 ; set 4-bit data, 2-line display
              JSR     cmd2LCD ; -"-
              LDAA    #$0C ; display on, cursor off, blinking off
              JSR     cmd2LCD ; -"-
              LDAA    #$06 ; move cursor right after entering a character
              JSR     cmd2LCD ; -"-
              RTS

cmd2LCD       BCLR LCD_CNTR,LCD_RS ; select the LCD Instruction Register (IR)
              JSR dataMov ; send data to IR
              RTS
del_50us      PSHX ;2 E-clk
eloop:        LDX #30 ;2 E-clk -

iloop:        PSHA ;2 E-clk |
              PULA ;3 E-clk |
              
              PSHA ;2 E-clk | 50us
              PULA ;3 E-clk |
              PSHA ;2
              PULA ;3
              PSHA ;2
              PULA ;3
              PSHA ;2
              PULA ;3
              PSHA ;2
              PULA  ;3
             
              PSHA  ;2
              PULA  ;3
              NOP ;1 E-clk |
              NOP       ;1 E-clk |
              DBNE X,iloop  ;3 E-clk -
              DBNE Y,eloop  ;3 E-clk
              PULX     ;3 E-clk
              RTS     ;5 E-clk
putsLCD       LDAA 1,X+ ; get one character from the string
              BEQ donePS ; reach NULL character?
              JSR putcLCD
              BRA putsLCD
donePS        RTS
putcLCD       BSET LCD_CNTR,LCD_RS ; select the LCD Data register (DR)
              JSR dataMov ; send data to DR
              RTS  
dataMov       BSET LCD_CNTR,LCD_E ; pull the LCD E-sigal high
              STAA LCD_DAT ; send the upper 4 bits of data to LCD
              BCLR LCD_CNTR,LCD_E ; pull the LCD E-signal low to complete the write oper.
              LSLA ; match the lower 4 bits with the LCD data pins
              LSLA ; -"-
              LSLA ; -"-
              LSLA ; -"-
              BSET LCD_CNTR,LCD_E ; pull the LCD E signal high
              STAA LCD_DAT ; send the lower 4 bits of data to LCD
              BCLR LCD_CNTR,LCD_E ; pull the LCD E-signal low to complete the write oper.
              LDY #1 ; adding this delay will complete the internal
              JSR del_50us ; operation for most instructions
              RTS
BIN2ASC         PSHA
                TAB
                ANDB #%00001111
                CLRA
                ADDD #HEX_TABLE
                XGDX
                LDAA 0,X
                
                PULB
                PSHA
                RORB
                RORB
                RORB
                RORB
                ANDB #%00001111
                CLRA
                ADDD #HEX_TABLE
                XGDX
                LDAA 0,X
                PULB
                RTS
initAD          MOVB #$C0,ATDCTL2     ;power up AD, select fast flag clear
                JSR del_50us          ;wait for 50 us
                MOVB #$00,ATDCTL3       ;8 conversions in a sequence
                MOVB #$85,ATDCTL4       ;res=8, conv-clks=2, prescal=12
                BSET ATDDIEN,$0C        ;configure pins AN03,AN02 as digital inputs
                RTS
ENABLE_TOF  LDAA    #%10000000
            STAA    TSCR1       ; Enable TCNT
            STAA    TFLG2       ; Clear TOF
            LDAA    #%10000100  ; Enable TOI and select prescale factor equal to 16
            STAA    TSCR2
            RTS               ; same as in Appendix B of this lab
TOF_ISR     INC     TOF_COUNTER
            LDAA    #%10000000         ; Clear
            STAA    TFLG2       ; TOF
            RTI                 ; --"--

;**************************************************************
;*                 Interrupt Vectors                          *
;**************************************************************
            ORG   $FFFE
            DC.W  Entry           ; Reset Vector
            ORG     $FFDE
            DC.W    TOF_ISR